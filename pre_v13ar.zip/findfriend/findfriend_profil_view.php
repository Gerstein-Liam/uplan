<!--                            PRESENSATION                                          -->
<div class="row" id="myprofil_header_container" >
<!--                            **IMAGE + DESC                                      -->  
<div class="col-md-6">
   <div class="row" >
     <figure>
             <div id="photo_profil_friend"></div>
            <figcaption>
               <div id="username"></div>
            </figcaption>
         </figure>
   </div>
</div>
<div class="col-md-6">
  <dl>
         <dt>
            Quick presentation
         </dt>
		<dd>
            <div id="quick_pres"></div>
         </dd>
       
         <dt>
            My position
         </dt>
         <dd>
            <div id="location"></div>
         </dd>
      </dl>
</div>
<!--                            PUBLICATION                                          -->
<div class="row" id="myprofil_pub_container" >
   <div class="col-md-12">
      <fieldset>
         <legend>UWall </legend>
         <div id="publications"></div>
      </fieldset>
   </div>
</div>

