<div class="row" >
   <div class="col-md-4">
      <div id="map_canvas"></div>
   </div>
   <div class="col-md-2">
      <div id="locatemenu_style">
         <form name="myForm"  id="myform" method="post" action="">
            <h4>Search preferences</h4>
            <p>woman/men?</p>
            <input type="text" name="sex" value=0>
            <p>distance</p>
            <input type="text" name="distance" value=0>
            <button type="button"  class="btn btn-success" id="button_launchsearch"  onclick="locatefriend()">Launch search</button>
         </form>
      </div>
   </div>
   <div class="col-md-6">
      <div id="friendprofil"></div>
   </div>
</div>

