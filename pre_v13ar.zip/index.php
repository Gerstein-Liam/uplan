<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Bootstrap 3, from LayoutIt!</title>
      <script src="main_controller.js"></script>
	  <script src="image_controller.js"></script>
	  
      <script src="signin/signin_controller.js"></script>
      <script src="login/login_controller.js"></script>
      <script src="myprofil/myprofil_controller.js"></script>
      <script src="findfriend/findfriend_controller.js"></script>
      <!-- API Google pour faire de l'AJAX  --> 
      <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <!-- API Google pour construire les graphiques "google chart" --> 
      <script type="text/javascript" src="https://www.google.com/jsapi"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
      <!-- API GoogleMAP"---------------------------------------- --> 
      <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyA4eY_LUmD83Jf9A3_cb0xvQZXAqXRsaVo"></script> 
      <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <!-- API Google pour construire les graphiques "google chart" --> 
      <script type="text/javascript" src="https://www.google.com/jsapi"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
      <!-- API GoogleMAP"---------------------------------------- --> 
      <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyA4eY_LUmD83Jf9A3_cb0xvQZXAqXRsaVo"></script> 
      <!-- Controleurs pour les differentes fonctions (modele MVC) " --> 
      <meta name="description" content="Source code generated using layoutit.com">
      <meta name="author" content="LayoutIt!">
      <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">
   </head>
   <body>
      <!--                            BLOCK PAGE                                             -->
      <div class="container-fluid">
         <!--                            HEADER                                           -->
         <div class="row" id="header_container">
            <div class="col-md-12">
               <div class="row" id="header_container">
                  <div class="col-md-4">
                     <img class="Image_titre" alt="Bootstrap Image Preview" src="images/logo.jpg">	
                  </div>
                  <div class="col-md-8">
                     <button type="button"  class="btn btn-success" id="button_sign" onclick="load_mainsection('signin')">
                     Sign In
                     </button> 
                  </div>
               </div>
            </div>
         </div>
         <!--                            MENU                                             -->
         <div class="row" id="mainmenu_container" >
            <div class="col-md-12">
               <ul class="nav nav-tabs">
                  <li class="active">
                     <button type="button" class="btn btn-default" onclick="load_mainsection('myprofil')">
                     My Profil
                     </button>
                  </li>
                  <li>
                     <button type="button" class="btn btn-default" onclick="load_mainsection('findfriend')">
                     Find Friends
                     </button>
                  </li>
                  <li>
                     <button type="button" class="btn btn-default" onclick="load_mainsection('findpeople')">
                     Find Peoples
                     </button>
                  </li>
                  <li>
                     <button type="button" class="btn btn-default" onclick="load_mainsection('findactivity')">
                     Find Actitivity
                     </button>
                  </li>
                  <li>
                     <button type="button" class="btn btn-default" onclick="load_mainsection('findtrip')">
                     Find Trip
                     </button>
                  </li>
				  <li>
                      <div  id="etat_connexion"></div>
                  </li>
                  <li>
                     <button type="button"  class="btn btn-default" id="button_logon" onclick="load_mainsection('login')">
                     Log in
                     </button>
                  </li>
                  <li>
                     <button type="button" class="btn btn-default" onclick="load_mainsection('logout')">
                     Log out
                     </button>
                  </li>
               </ul>
               </li>
               </ul>
            </div>
         </div>
         <!--                               SECTION ( PARTIE DYNAMIQUE)                                             -->
         <div class="row" id="mainsection_container"  >
            <div  id="mainsection_content"></div>
         </div>
         <!--                               CHAT                                           -->
         <!--                               FOOTER (DEV)                                   -->
         <div class="row" id="chat_container" ></div>
         <div class="row" id="footer_container" >
            <div class="row" id="devbox_container">
               <div class="col-md-6" id="devbox">
                  <p>Development input</p>
                  <form name="myFormdev" method="post" action="">
                     <p>Offset latitude (outil dev)</p>
                     <input type="text" name="off_lat" value=0>
                     <p>Offset longitude (outil dev)</p>
                     <input type="text" name="off_lon" value=0>
                  </form>
               </div>
               <div class="col-md-6" id="devbox">
                  <p>Console serveur (outil dev)</p>
                  <div id="reponse_server"></div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>

