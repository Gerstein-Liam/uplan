<div class="row">
   <div class="col-md-12">
      <form name="myForm"  id="myform" method="post" action="">
         <div class="form-group">
            <p >
               Username
            </p>
            <input size="170" type="text" name="username">
         </div>
         <div class="form-group">
            <p for="exampleInputPassword1">
               Password
            </p>
            <input size="170" type="password" name="password">
         </div>
         <button type="button" class="btn btn-default" onclick="login()">
         Log in
         </button>
      </form>
   </div>
</div>
<div class="row">
   <div class="col-md-12">
      <p >
      <div  id="etat_connexion_loginview"></div>
      </p>
   </div>
</div>

