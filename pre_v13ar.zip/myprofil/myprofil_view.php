<!--                            PRESENSATION                                          -->
<div class="row" id="myprofil_header_container" >
   <!--                            **IMAGE + DESC                                      -->  
   <div class="col-md-3">
      <div class="row" >
         <figure>
             <div id="photo_profil"></div>
            <figcaption>
               <div id="username"></div>
            </figcaption>
         </figure>
      </div>
   </div>
   <div class="col-md-3">
      <dl>
         <dt>
            Quick presentation
         </dt>
		<dd>
            <div id="quick_pres"></div>
         </dd>

         <dt>
            My position
         </dt>
         <dd>
            <div id="location"></div>
         </dd>
      </dl>
   </div>
   
   
   
   
   
   <!--                            **EDITION                                         -->   
   <div class="col-md-6">
      <div class="row">
         <div class="col-md-6">
            <p >Quick presentation</p>
            <input size="25" type="text" name="new_quick_pres" id="new_quick_pres">
			<button type="button" class="btn btn-default" onclick="update_pres_profil()">  Change presentation
           </button>

         </div>
         <div class="col-md-6">
         <input type="file" name="filename" id="filename" />
				<button type="button" class="btn btn-default" onclick="update_photo_profil()">  Change photo
         </button>
         </div>
      </div>
   </div>
</div>
<!--                            PUBLIER                                             -->
<div class="row" id="myprofil_addpub_container">
   <div class="col-md-10" id="myprofil-text_align">
      <form name="myForm" method="post" action="">
         <input size="170" type="text" name="new_pub_content">
      </form>
   </div>
   <div class="col-md-2">
      <button type="button" style="width:130px" onclick="publish()"  value="submit">Publish</button>
   </div>
</div>
<!--                            PUBLICATION                                          -->
<div class="row" id="myprofil_pub_container" >
   <div class="col-md-12">
      <fieldset>
         <legend>UWall </legend>
         <div id="publications"></div>
      </fieldset>
   </div>
</div>