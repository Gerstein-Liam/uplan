<div class="row">
   <div class="col-md-6">
      <form name="myForm" id="myform" method="post" action="">
         <div class="form-group">
            <p for="exampleInputEmail1">
               Email adress
            </p>
            <input size="100" type="text" name="email">
         </div>
         <div class="form-group">
            <p >
               Username
            </p>
            <input size="100" type="text" name="username">
         </div>
         <div class="form-group">
            <p for="exampleInputPassword1">
               Password
            </p>
            <input size="100" type="password" name="password">
         </div>
         <div class="form-group">
            <p for="exampleInputPassword1">
               Repeat Password
            </p>
            <input size="100" type="password" name="repeated_password">
         </div>
		 <div class="form-group">
            <p for="exampleInputEmail1">
               Quick presentation 
            </p>
            <input size="100" type="text" name="quick_pres">
         </div>
		 
         <div class="form-group">
		<input type="file" name="filename" id="filename" />
		<button type="button" class="btn btn-default" onclick="signin()">  Sign in
         </button>
         </div>
		 
      
      </form>
	  
	
	  
   </div>
   
   
     <div class="col-md-6"  id="photo_signin">
  
   </div>
</div>

