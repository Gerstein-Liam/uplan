<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Bootstrap 3, from LayoutIt!</title>
      <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">
   </head>
   <body>
      <!--                            BLOCK PAGE                                             -->
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-1 col-xs-1">
               <img class="Image_titre" alt="Bootstrap Image Preview" src="images/logo.jpg">	
            </div>
            <div class="col-md-9 col-xs-9">
               <nav>
                  <button type="button" id="main_menu_bt" class="main_menu_button" onclick="load_mainsection('myprofil')">
                  Profil
                  </button>
                  <button type="button" id="main_menu_bt" class="main_menu_button" onclick="load_mainsection('findpeople')">
                  Find 
                  </button>
               </nav>
            </div>
            <div class="col-md-1 col-xs-1">
               <img class="Image_titre" alt="Bootstrap Image Preview" src="images/logoff.jpg">
            </div>
         </div>
         <div class="row" id="main_section_container">
            <div class="col-md-1 col-xs-1" id="menu_section">
            </div>
            <div class="col-md-10 col-xs-10" id="contenu_section">
               <div class="row" id="miniprofil_container">
               </div>
               <div class="row" id="map_container">
               </div>
            </div>
         </div>
         <div class="row" id="chat_section_container">
         </div>
      </div>
   </body>
</html>